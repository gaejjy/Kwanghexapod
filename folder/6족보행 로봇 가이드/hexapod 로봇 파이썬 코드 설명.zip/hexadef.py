import time


class Joint(object):#로봇의 각 관절들을 어깨 팔굼치 손목이라고 생각한다면 그것들은 모두 joint에서 분화되어서 나오는 클래스들입니다
    pwm = None
    connector = None
    min_rotation = 0
    max_rotation = 100

    def __init__(self, pwm, connector, min=None, max=None):#init 키워드는 생성자입니다. 각 관절이라는 객체(클래스)를 만들때 그냥 만드는게 아니며, 다음과 같이 클래스가 가진 값들(pwm , connector, min_rota, max_rota등을 설정한다는 거죠)
        self.pwm = pwm#hexamain에서 pwm 을 뭘로 해줄지 에 따라서 여기에 넣어줍니다. pwm1 = ex) PWM(0x40) 라는 코드를 써서 shoulder6개는 첫번재 adafruit 기판에 배치
        self.connector = connector#채널값 즉 shoulder 는 0부터 5까지.. elbow 는 2번 adafruit 보드의 0부터 5까지 wrist 는 2번보드의 6부터 ....

        if min is not None:
            self.min_rotation = min# 클래스를 생성할때 여기에 min과 max 값을 설정 ex) shoulder_0 = Shoulder(pwm1, 0,450,310)는 pwm1이라고 설정한 adafruit 기판의 0번 채널, min 450, max 310 이렇게 설정해준다는 뜻

        if max is not None:
            self.max_rotation = max

    def move_min(self):#() 표시가 붙는다면 전부 함수(메서드)라고 생각하세요 
        self.pwm.setPWM(self.connector, 0, self.min_rotation)

    def move_mid(self):
        if self.min_rotation > self.max_rotation:
            mid_rotation = ((self.min_rotation - self.max_rotation) / 2) + self.max_rotation#최대값과 최소값 합의 2분의 1을 회전한다는 뜻.. move 가 붙으면 회전을 담당하는 함수라고 생각하세요
        else:
            mid_rotation = ((self.max_rotation - self.min_rotation) / 2) + self.min_rotation
        self.pwm.setPWM(self.connector, 0, mid_rotation)

    def move_max(self):
        self.pwm.setPWM(self.connector, 0, self.max_rotation)

    def middle(self):# notimplemented 키워드는 이 기본 클래스를 계승받는 자식 클래스들(shoulder elbow wrist등) 이 구현할 함수입니다. 이러한 자식 클래스는 부모클래스가 가진 함수를 그대로 사용하기도 하며 자신의 스타일에 맞게 고칠 수도 있죠.
        raise NotImplementedError

    def up(self):
        raise NotImplementedError
    def down(self):
        raise NotImplementedError


class Shoulder(Joint):
    min_rotation = 250
    max_rotation = 400

    def middle(self):
        self.move_mid()#부모 클래스의 move_mid 메서드를 자식클래스의middle() 함수로 사용한다는 뜻입니다. 사실 굳이 middle()이라는 함수를 정의할 필요는 없지만 우리가 움직일 때 생각하기 편하게 하기 위해서 정의했었요

    def up(self):
        self.move_max()
    def down(self):
        self.move_min()

class Elbow(Joint):
	min_rotation = 250
	max_rotation = 400
	
	def middle(self):
		self.move_min()
	def up(self):
		self.move_max()
	def down(self):
		self.move_mid()

class Wrist(Joint):
    

	min_rotation = 250
	max_rotation = 400
	def middle(self):
		self.move_min()
	def up(self):
		self.move_max()
	def down(self):
		self.move_mid()

class Arm(object):#팔하나는 결국 shoulder elbow wrist 로 구성되는 거죠. 
    shoulder = None
    elbow = None
    wrist = None

    def __init__(self, shoulder, elbow, wrist):# 팔하나 객체가 만들기 위해서는 다음과 같이 된다는 뜻입니다. 
        self.shoulder = shoulder
        self.elbow = elbow
        self.wrist = wrist
	def stand(self):#이제 이팔이 가진 함수를 정의하고 구현하는 거죠 각 관절부분들의 함수를 조합해서 만들었습니다. 
		self.shoulder.middle()
		self.elbow.down()
		self.wrist.down()
	def Up_Go(self):
		self.shoulder.up()
		self.elbow.up()
		wrist.up()

class Hexapod(object):#이제 팔 6개는 다시 로봇 하나가 됩니다. 사실 여기다가 로봇 움직임 함수를 정의할 수 있었는데 오류가 잘 떠서 main에다가 구현한거죠. 
    arm_1 = None
    arm_2 = None
    arm_3 = None
    arm_4 = None
    arm_5 = None
    arm_6 = None

    sleep_time = 2

    def __init__(self, arm_1, arm_2, arm_3, arm_4, arm_5, arm_6, sleep_time=None):
        """
        Hexapod skeleton
        @type arm_1: Arm
        @type arm_2: Arm
        @type arm_3: Arm
        @type arm_4: Arm
        @type arm_5: Arm
        @type arm_6: Arm
        """
        self.arm_1 = arm_1
        self.arm_2 = arm_2
        self.arm_3 = arm_3
        self.arm_4 = arm_4
        self.arm_5 = arm_5
        self.arm_6 = arm_6

        if sleep_time is not None:
            self.sleep_time = sleep_time
	def stand(self):
		self.arm_1.stand()
		self.arm_2.stand()
		self.arm_3.stand()
		self.arm_4.stand()
		self.arm_5.stand()
		self.arm_6.stand()
